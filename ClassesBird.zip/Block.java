import java.util.Vector;

public class Block {

  public String texturePath;

    public Vector  myGameState;
    public Vector  myGameState;

}