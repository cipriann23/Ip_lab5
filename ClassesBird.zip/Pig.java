import java.util.Vector;

public class Pig {

  public integer health;

    public Vector  myGameState;
    public Vector  myGameState;

  public void die() {
  }

}