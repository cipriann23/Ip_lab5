public class PhysicsObject extends Block, Bird, Pig {

  public float posX;

  public float posY;

  public int weight;

  public int width;

  public int height;

  public float vX;

  public float vY;

  public float angle;

  public void computeNextState() {
  }

}