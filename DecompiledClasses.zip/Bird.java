// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 21-Mar-17 9:08:32 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Bird.java


public class Bird extends PhysicsObject
{

    public Bird()
    {
    }

    public String color;
    public String power;
}