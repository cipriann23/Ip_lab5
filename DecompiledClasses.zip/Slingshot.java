// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 21-Mar-17 9:03:41 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Slingshot.java


public class Slingshot
{

    public Slingshot()
    {
    }

    public void launch(int i, int j, Bird bird)
    {
    }

    public float posX;
    public float posY;
}