// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 21-Mar-17 9:09:00 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PhysicsObject.java


public class PhysicsObject
{

    public PhysicsObject()
    {
    }

    public void computeNextState()
    {
    }

    public float posX;
    public float posY;
    public int weight;
    public int width;
    public int height;
    public float vX;
    public float vY;
    public float angle;
}