import java.util.Vector;

public class Slingshot {

  public float posX;

  public float posY;

    public Vector  myGameState;
    public Vector  myGameState;
    public Vector  myGameState;

  public void launch( x,  y,  bird) {
  }

}