import java.util.Vector;

public class Bird extends PhysicsObject {

  public string color;

  public string power;

    public Vector  myGameState;
    public Vector  myGameState;

}