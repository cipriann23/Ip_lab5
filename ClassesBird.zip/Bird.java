import java.util.Vector;

public class Bird {

  public string color;

  public string power;

    public Vector  myGameState;

}