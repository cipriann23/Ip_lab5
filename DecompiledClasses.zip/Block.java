// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 21-Mar-17 9:08:41 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Block.java


public class Block extends PhysicsObject
{

    public Block()
    {
    }

    public String texturePath;
}