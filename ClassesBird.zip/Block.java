import java.util.Vector;

public class Block extends PhysicsObject {

  public String texturePath;

    public Vector  myGameState;
    public Vector  myGameState;
    public Vector  myGameState;

}