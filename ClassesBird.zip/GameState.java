import java.util.Vector;

public class GameState {

  public int score;

  public ArrayList<Pig> pigs;

  public ArrayList<Bird> birds;

  public int level;

  public Slingshot slingshot;

  public ArrayList<Block> blocks;

  public int frameCtr;

  public GameState instance;

    public Vector  myPig;
    public Vector  myPig;
    public Vector  myBird;
      public Vector  myBlock;
    public Vector  myBlock;
    public Vector  mySlingshot;
    public Vector  mySlingshot;
    public Vector  myBlock;
    public Vector  myBird;
    public Vector  myPig;

  public void nextFrame() {
  }

  public void getInstance() {
  }

}