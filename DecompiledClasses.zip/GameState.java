// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 21-Mar-17 9:08:52 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   GameState.java

import java.util.ArrayList;
import java.util.Vector;

public class GameState
{

    public GameState()
    {
    }

    public void nextFrame()
    {
    }

    public void getInstance()
    {
    }

    public int score;
    public ArrayList pigs;
    public ArrayList birds;
    public int level;
    public Slingshot slingshot;
    public ArrayList blocks;
    public int frameCtr;
    public GameState instance;
    public Vector myPig;
    public Vector myBird;
    public Vector myBlock;
    public Vector mySlingshot;
}